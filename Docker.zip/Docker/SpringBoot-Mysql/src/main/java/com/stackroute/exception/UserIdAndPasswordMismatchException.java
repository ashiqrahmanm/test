package com.stackroute.exception;

public class UserIdAndPasswordMismatchException extends Exception {

    public UserIdAndPasswordMismatchException(String message) {
        super(message);
    }
}

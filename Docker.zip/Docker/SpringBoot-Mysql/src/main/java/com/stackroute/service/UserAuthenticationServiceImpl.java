package com.stackroute.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.stackroute.exception.UserAlreadyExistsException;
import com.stackroute.exception.UserNotFoundException;
import com.stackroute.model.User;
import com.stackroute.repository.UserAutheticationRepository;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn't currently 
* provide any additional behavior over the @Component annotation, but it's a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */


@Service
public class UserAuthenticationServiceImpl implements UserAuthenticationService {

    /*
	 * Autowiring should be implemented for the UserAuthenticationRepository. (Use
	 * Constructor-based autowiring) Please note that we should not create any
	 * object using the new keyword.
	 */


     private UserAutheticationRepository userAutheticationRepository;
     
     public UserAuthenticationServiceImpl(UserAutheticationRepository userAutheticationRepository )
     {
    	 this.userAutheticationRepository = userAutheticationRepository;
     }


     /*
	 * This method should be used to validate a user using userId and password.
	 *  Call the corresponding method of Respository interface.
	 * 
	 */
    @Override
    public User findByUserIdAndPassword(String userId, String password) throws UserNotFoundException {

    	User user = userAutheticationRepository.findByUserIdAndUserPassword(userId, password);
    	if(user==null)
    	{
    		throw new UserNotFoundException("User does not exist with this credentials");
    	}
    	return user;
    	
    }




	/*
	 * This method should be used to save a new user.Call the corresponding method
	 * of Respository interface.
	 */

    @Override
    public boolean saveUser(User user) throws UserAlreadyExistsException {
       
    	try
    	{
    		Optional<User> existingUser = userAutheticationRepository.findById(user.getUserId());
    		if(existingUser.isPresent())
    		{
    			throw new UserAlreadyExistsException("User Already exist with this id : " + user.getUserId());
    		}
    		
    		
    		userAutheticationRepository.save(user);
    		return true;
    		
    	}
    	catch(Exception e)
    	{ e.printStackTrace();
    		throw new UserAlreadyExistsException("Cannot Register User");
    	}
    }
}
